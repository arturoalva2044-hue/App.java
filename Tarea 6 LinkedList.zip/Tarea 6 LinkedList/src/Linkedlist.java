import java.util.Iterator;

public class LinkedList<E> implements Lista<E> {

    private static class Nodo<E> {
        E dato;
        Nodo<E> siguiente;
        Nodo<E> anterior;

        Nodo(E dato) {
            this.dato = dato;
        }
    }

    private Nodo<E> cabeza = null;
    private Nodo<E> cola = null;
    private int tamano = 0;

    public LinkedList() {

    }

    private Nodo<E> obtenerNodo(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }

        Nodo<E> temp;
        if (posicion < tamano / 2) {
            temp = cabeza;
            for (int i = 0; i < posicion; i++) {
                temp = temp.siguiente;
            }
        } else {
            temp = cola;
            for (int i = tamano - 1; i > posicion; i--) {
                temp = temp.anterior;
            }
        }
        return temp;
    }

    // 1. Agrega un elemento al final de la colección
    @Override
    public void agregarElemento(E e) {
        agregarFinal(e);
    }

    // 2. Agrega un elemento al inicio de la colección
    @Override
    public void agregarInicio(E e) {
        Nodo<E> nuevoNodo = new Nodo<>(e);
        if (esVacia()) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            nuevoNodo.siguiente = cabeza;
            cabeza.anterior = nuevoNodo;
            cabeza = nuevoNodo;
        }
        tamano++;
    }

    // 3. Agrega un elemento al final de la colección
    @Override
    public void agregarFinal(E e) {
        Nodo<E> nuevoNodo = new Nodo<>(e);
        if (esVacia()) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.siguiente = nuevoNodo;
            nuevoNodo.anterior = cola;
            cola = nuevoNodo;
        }
        tamano++;
    }

    // 4. Agrega un elemento en una determinada posición
    @Override
    public void agregarPosicion(E e, int posicion) {
        if (posicion < 0 || posicion > tamano) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }

        if (posicion == 0) {
            agregarInicio(e);
        } else if (posicion == tamano) {
            agregarFinal(e);
        } else {
            Nodo<E> nuevoNodo = new Nodo<>(e);
            Nodo<E> actual = obtenerNodo(posicion);
            Nodo<E> previo = actual.anterior;

            previo.siguiente = nuevoNodo;
            nuevoNodo.anterior = previo;
            nuevoNodo.siguiente = actual;
            actual.anterior = nuevoNodo;

            tamano++;
        }
    }

    // 5. Elimina un elemento del final de la colección (Comportamiento por defecto)
    @Override
    public E eliminarElemento() {
        return eliminarElementoFinal();
    }

    // 6. Elimina un elemento del inicio de la colección
    @Override
    public E eliminarElementoInicio() {
        if (esVacia()) {
            throw new IllegalStateException("La lista está vacía");
        }
        E datoEliminado = cabeza.dato;
        if (tamano == 1) {
            cabeza = null;
            cola = null;
        } else {
            cabeza = cabeza.siguiente;
            cabeza.anterior = null;
        }
        tamano--;
        return datoEliminado;
    }

    // 7. Elimina un elemento del final de la colección
    @Override
    public E eliminarElementoFinal() {
        if (esVacia()) {
            throw new IllegalStateException("La lista está vacía");
        }
        E datoEliminado = cola.dato;
        if (tamano == 1) {
            cabeza = null;
            cola = null;
        } else {
            cola = cola.anterior;
            cola.siguiente = null;
        }
        tamano--;
        return datoEliminado;
    }

    // 8. Elimina un elemento de una determinada posición
    @Override
    public E eliminarElementoPosicion(int posicion) {
        if (posicion < 0 || posicion >= tamano) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }

        if (posicion == 0) {
            return eliminarElementoInicio();
        } else if (posicion == tamano - 1) {
            return eliminarElementoFinal();
        } else {
            Nodo<E> actual = obtenerNodo(posicion);
            E datoEliminado = actual.dato;

            Nodo<E> previo = actual.anterior;
            Nodo<E> siguiente = actual.siguiente;

            previo.siguiente = siguiente;
            siguiente.anterior = previo;

            tamano--;
            return datoEliminado;
        }
    }

    // 9. Regresa verdadero si la colección es vacía
    @Override
    public boolean esVacia() {
        return tamano == 0;
    }

    // 10. Regresa el número de elementos de la colección
    @Override
    public int numElementos() {
        return tamano;
    }

    // 11. Elimina todos los elementos de la lista
    @Override
    public void limpiarLista() {
        cabeza = null;
        cola = null;
        tamano = 0;
    }

    // 12. Regresa la colección como un arreglo
    @Override
    @SuppressWarnings("unchecked")
    public E[] convertirArreglo() {
        E[] arreglo = (E[]) new Object[tamano];
        Nodo<E> temp = cabeza;
        int i = 0;
        while (temp != null) {
            arreglo[i] = temp.dato;
            temp = temp.siguiente;
            i++;
        }
        return arreglo;
    }

    // 13. Regresa el elemento en una posición particular
    @Override
    public E consultar(int posicion) {
        return obtenerNodo(posicion).dato;
    }

    // Método iterator() para implementar Iterable<E> y permitir ciclos for-each
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private Nodo<E> temp = cabeza;

            @Override
            public boolean hasNext() {
                return temp != null;
            }

            @Override
            public E next() {
                if (!hasNext()) {
                    // Usamos la excepción estándar IllegalStateException (no requiere import)
                    throw new IllegalStateException("No hay más elementos en la iteración");
                }
                E valor = temp.dato;
                temp = temp.siguiente;
                return valor;
            }
        };
    }
}