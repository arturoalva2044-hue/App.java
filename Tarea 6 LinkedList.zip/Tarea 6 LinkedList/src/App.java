public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("=== Probando los 13 Métodos de la Interfaz Lista ===\n");

        // Inicialización de la lista de tipo String
        Lista<String> lista = new ArrayListcomple<>();

        // METODO 9: esVacia()
        System.out.println("1. ¿La lista está vacía al inicio?: " + lista.esVacia());

        // METODO 1: agregarElemento(E e)
        lista.agregarElemento("A"); 
        System.out.println("\n2. agregarElemento('A') ejecutado.");

        // METODO 3: agregarFinal(E e)
        lista.agregarFinal("C");
        System.out.println("3. agregarFinal('C') ejecutado.");

        // METODO 2: agregarInicio(E e)
        lista.agregarInicio("Inicio");
        System.out.println("4. agregarInicio('Inicio') ejecutado.");

        // METODO 4: agregarPosicion(E e, int posicion)
        lista.agregarPosicion("B", 2); // Debería quedar entre A y C
        System.out.println("5. agregarPosicion('B', 2) ejecutado.");

        // Imprimir usando el iterador para ver cómo va
        System.out.print("   Estado actual de la lista: ");
        for (String el : lista) System.out.print("[" + el + "] ");
        System.out.println();

        // METODO 10: numElementos()
        System.out.println("\n6. numElementos(): " + lista.numElementos());

        // METODO 13: consultar(int posicion)
        System.out.println("7. consultar(1) [Debe ser A]: " + lista.consultar(1));

        // METODO 12: convertirArreglo()
        System.out.println("\n8. Probando convertirArreglo()...");
        String[] copiaArreglo = lista.convertirArreglo();
        System.out.println("   Tamaño del arreglo devuelto: " + copiaArreglo.length);
        System.out.println("   Elemento en índice 0 del arreglo nativo: " + copiaArreglo[0]);

        // METODO 6: eliminarElementoInicio()
        System.out.println("\n9. eliminarElementoInicio(): " + lista.eliminarElementoInicio());

        // METODO 8: eliminarElementoPosicion(int posicion)
        System.out.println("10. eliminarElementoPosicion(1) [Elimina la B]: " + lista.eliminarElementoPosicion(1));

        // METODO 7: eliminarElementoFinal()
        System.out.println("11. eliminarElementoFinal() [Elimina la C]: " + lista.eliminarElementoFinal());

        // METODO 5: eliminarElemento()
        System.out.println("12. eliminarElemento() [Elimina el último restante, la A]: " + lista.eliminarElemento());

        // Verificar si quedó vacía tras eliminar todo de forma individual
        System.out.println("   ¿La lista quedó vacía tras las bajas?: " + lista.esVacia());

        // Llenamos rápido otra vez para probar el último método
        lista.agregarElemento("X");
        lista.agregarElemento("Y");

        // METODO 11: limpiarLista()
        System.out.println("\n13. Probando limpiarLista()...");
        lista.limpiarLista();
        System.out.println("    ¿La lista está vacía ahora?: " + lista.esVacia());
        System.out.println("    Número de elementos final: " + lista.numElementos());
    }
}