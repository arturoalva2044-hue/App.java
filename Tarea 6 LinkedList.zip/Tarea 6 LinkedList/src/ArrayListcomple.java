import java.util.Iterator;

public class ArrayListcomple<E> implements Lista<E> {

    // Tamaño máximo inicial por defecto del arreglo
    private static final int MAX = 5;

    // Indica cuántos elementos tiene actualmente la lista
    private int indice = 0;

    // Arreglo donde se almacenan los datos
    private Object[] datos = null; 

    // Constructor por defecto
    public ArrayListcomple() {
        this(MAX);
    }

    // Constructor con tamaño inicial personalizado
    public ArrayListcomple(int tam) {
        if (tam < 0) {
            throw new IllegalArgumentException("El tamaño no puede ser negativo");
        }
        datos = new Object[tam];
    }

    // Método privado para asegurar que el arreglo crezca si se llena
    private void verificarYCrecer() {
        if (indice >= datos.length) {
            // Crecimiento del 50% + 1 elemento de seguridad
            Object[] aux = new Object[datos.length + datos.length / 2 + 1];
            System.arraycopy(datos, 0, aux, 0, datos.length);
            datos = aux; 
        }
    }

    // 1. Agrega un elemento al final de la colección
    @Override
    public void agregarElemento(E e) {
        verificarYCrecer();
        datos[indice] = e;
        indice++;
    }

    // 2. Agrega un elemento al inicio de la colección
    @Override
    public void agregarInicio(E e) {
        verificarYCrecer();
        // Mueve todos los elementos una posición a la derecha
        System.arraycopy(datos, 0, datos, 1, indice);
        datos[0] = e;
        indice++;
    }

    // 3. Agrega un elemento al final de la colección (Duplicado explícito)
    @Override
    public void agregarFinal(E e) {
        verificarYCrecer();
        datos[indice] = e;
        indice++;
    }

    // 4. Agrega un elemento en una determinada posición
    @Override
    public void agregarPosicion(E e, int posicion) {
        if (posicion < 0 || posicion > indice) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        verificarYCrecer();
        // Mueve los elementos desde la posición deseada a la derecha
        System.arraycopy(datos, posicion, datos, posicion + 1, indice - posicion);
        datos[posicion] = e;
        indice++;
    }

    // 5. Elimina un elemento del final de la colección (Comportamiento por defecto)
    @Override
    public E eliminarElemento() {
        if (esVacia()) {
            throw new IllegalStateException("La lista está vacía");
        }
        indice--;
        @SuppressWarnings("unchecked")
        E eliminado = (E) datos[indice];
        datos[indice] = null; // Liberar memoria
        return eliminado;
    }

    // 6. Elimina un elemento del inicio de la colección
    @Override
    public E eliminarElementoInicio() {
        if (esVacia()) {
            throw new IllegalStateException("La lista está vacía");
        }
        @SuppressWarnings("unchecked")
        E eliminado = (E) datos[0];
        
        // Mueve todos los elementos una posición a la izquierda
        System.arraycopy(datos, 1, datos, 0, indice - 1);
        indice--;
        datos[indice] = null; // Liberar memoria
        return eliminado;
    }

    // 7. Elimina un elemento del final de la colección
    @Override
    public E eliminarElementoFinal() {
        if (esVacia()) {
            throw new IllegalStateException("La lista está vacía");
        }
        indice--;
        @SuppressWarnings("unchecked")
        E eliminado = (E) datos[indice];
        datos[indice] = null; // Liberar memoria
        return eliminado;
    }

    // 8. Elimina un elemento de una determinada posición
    @Override
    public E eliminarElementoPosicion(int posicion) {
        if (posicion < 0 || posicion >= indice) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        @SuppressWarnings("unchecked")
        E eliminado = (E) datos[posicion];
        
        // Calcula cuántos elementos hay que mover a la izquierda
        int elementosAMover = indice - posicion - 1;
        if (elementosAMover > 0) {
            System.arraycopy(datos, posicion + 1, datos, posicion, elementosAMover);
        }
        indice--;
        datos[indice] = null; // Liberar memoria
        return eliminado;
    }

    // 9. Regresa verdadero si la colección es vacía
    @Override
    public boolean esVacia() {
        return indice == 0;
    }

    // 10. Regresa el número de elementos de la colección
    @Override
    public int numElementos() {
        return indice;
    }

    // 11. Elimina todos los elementos de la lista
    @Override
    public void limpiarLista() {
        for (int i = 0; i < indice; i++) {
            datos[i] = null; // Limpieza segura para el Garbage Collector
        }
        indice = 0;
    }

    // 12. Regresa la colección como un arreglo nativo
    @Override
    @SuppressWarnings("unchecked")
    public E[] convertirArreglo() {
        E[] arreglo = (E[]) new Object[indice];
        System.arraycopy(datos, 0, arreglo, 0, indice);
        return arreglo;
    }

    // 13. Regresa el elemento en una posición particular
    @Override
    @SuppressWarnings("unchecked")
    public E consultar(int posicion) {
        if (posicion < 0 || posicion >= indice) {
            throw new IndexOutOfBoundsException("Posición fuera de rango: " + posicion);
        }
        return (E) datos[posicion];
    }

    // Método de la interfaz Iterable para usar ciclos for-each
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int current = 0;

            @Override
            public boolean hasNext() {
                return current < indice;
            }

            @Override
            @SuppressWarnings("unchecked")
            public E next() {
                E valor = (E) datos[current];
                current++;
                return valor;
            }
        };
    }
}